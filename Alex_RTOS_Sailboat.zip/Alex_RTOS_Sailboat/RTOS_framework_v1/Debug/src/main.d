src/main.d src/main.o: ../src/main.c ../src/sail_ctrl.h \
 ../src/ASF/common2/services/delay/delay.h \
 ../src/ASF/common2/services/delay/sam0/cycle_counter.h \
 ../src/ASF/sam0/utils/compiler.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stddef.h \
 ../src/ASF/common/utils/parts.h ../src/ASF/sam0/utils/status_codes.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdint.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\stdint.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_default_types.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\features.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_newlib_version.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_intsup.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_stdint.h \
 ../src/ASF/sam0/utils/preprocessor/preprocessor.h \
 ../src/ASF/sam0/utils/preprocessor/tpaste.h \
 ../src/ASF/sam0/utils/preprocessor/stringz.h \
 ../src/ASF/sam0/utils/preprocessor/mrepeat.h \
 ../src/ASF/sam0/utils/preprocessor/preprocessor.h \
 ../src/ASF/sam0/utils/preprocessor/mrecursion.h \
 ../src/ASF/sam0/utils/header_files/io.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdbool.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/samd20.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/samd20j18.h \
 ../src/ASF/thirdparty/CMSIS/Include/core_cm0plus.h \
 ../src/ASF/thirdparty/CMSIS/Include/cmsis_version.h \
 ../src/ASF/thirdparty/CMSIS/Include/cmsis_compiler.h \
 ../src/ASF/thirdparty/CMSIS/Include/cmsis_gcc.h \
 ../src/ASF/sam0/utils/cmsis/samd20/source/system_samd20.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/ac.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/adc.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/dac.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/dsu.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/eic.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/evsys.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/gclk.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/nvmctrl.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/pac.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/pm.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/port.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/rtc.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/sercom.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/sysctrl.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/tc.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/component/wdt.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/ac.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/adc.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/dac.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/dsu.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/eic.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/evsys.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/gclk.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/nvmctrl.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/pac0.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/pac1.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/pac2.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/pm.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/port.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/rtc.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom0.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom1.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom2.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom3.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom4.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom5.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/sysctrl.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc0.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc1.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc2.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc3.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc4.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc5.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc6.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc7.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/instance/wdt.h \
 ../src/ASF/sam0/utils/cmsis/samd20/include/pio/samd20j18.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\stdio.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_ansi.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\newlib.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\config.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\ieeefp.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\cdefs.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdarg.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\reent.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_ansi.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_types.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_types.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\lock.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\types.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\endian.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_endian.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\select.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_sigset.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_timeval.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\timespec.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_timespec.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_pthreadtypes.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\types.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\stdio.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\stdlib.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\stdlib.h \
 d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\alloca.h \
 ../src/ASF/common/utils/interrupt.h \
 ../src/ASF/common/utils/interrupt/interrupt_sam_nvic.h \
 ../src/ASF/sam0/drivers/system/clock/clock.h \
 ../src/ASF/sam0/drivers/system/clock/gclk.h \
 ../src/ASF/sam0/drivers/system/clock/clock_samd20/clock_feature.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/FreeRTOS.h \
 ../src/config/FreeRTOSConfig.h ../src/ASF/common/boards/board.h \
 ../src/ASF/sam0/boards/samd20_xplained_pro/samd20_xplained_pro.h \
 ../src/config/conf_board.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/projdefs.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/portable.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/deprecated_definitions.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/portable/GCC/ARM_CM0/portmacro.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/mpu_wrappers.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/task.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/list.h \
 ../src/asf.h ../src/ASF/sam0/drivers/adc/adc.h \
 ../src/ASF/sam0/drivers/system/system.h \
 ../src/ASF/sam0/drivers/system/pinmux/pinmux.h \
 ../src/ASF/sam0/drivers/system/power/power_sam_d_r_h/power.h \
 ../src/ASF/sam0/drivers/system/reset/reset_sam_d_r_h/reset.h \
 ../src/ASF/sam0/drivers/adc/adc_sam_d_r_h/adc_feature.h \
 ../src/ASF/sam0/drivers/system/interrupt/system_interrupt.h \
 ../src/ASF/sam0/drivers/system/interrupt/system_interrupt_samd20/system_interrupt_features.h \
 ../src/ASF/sam0/drivers/adc/adc_callback.h \
 ../src/ASF/common/services/freertos/dbg_print/dbg_print.h \
 ../src/config/conf_dbg_print.h \
 ../src/ASF/common/services/freertos/dbg_print/quick_start_basic/qs_dbg_print_basic.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/StackMacros.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/croutine.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/deprecated_definitions.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/event_groups.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/timers.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/task.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/list.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/message_buffer.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/stream_buffer.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/mpu_wrappers.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/portable.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/projdefs.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/queue.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/semphr.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/queue.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/stack_macros.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/stream_buffer.h \
 ../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/timers.h \
 ../src/ASF/sam0/drivers/port/port.h \
 ../src/ASF/sam0/drivers/rtc/rtc_count.h ../src/config/conf_clocks.h \
 ../src/ASF/sam0/drivers/rtc/rtc_count_interrupt.h \
 ../src/ASF/sam0/drivers/rtc/rtc_count.h \
 ../src/ASF/sam0/drivers/rtc/rtc_tamper.h \
 ../src/ASF/sam0/drivers/sercom/sercom.h \
 ../src/ASF/sam0/drivers/sercom/sercom_pinout.h \
 ../src/ASF/sam0/drivers/sercom/sercom_interrupt.h \
 ../src/ASF/sam0/drivers/sercom/sercom.h \
 ../src/ASF/sam0/drivers/sercom/i2c/i2c_common.h \
 ../src/ASF/sam0/drivers/sercom/i2c/i2c_master.h \
 ../src/ASF/sam0/drivers/sercom/i2c/i2c_common.h \
 ../src/ASF/sam0/drivers/sercom/i2c/i2c_master_interrupt.h \
 ../src/ASF/sam0/drivers/sercom/i2c/i2c_master.h \
 ../src/ASF/sam0/drivers/sercom/usart/usart.h \
 ../src/ASF/sam0/drivers/sercom/usart/usart_interrupt.h \
 ../src/ASF/sam0/drivers/sercom/usart/usart.h \
 ../src/ASF/sam0/drivers/tc/tc.h \
 ../src/ASF/sam0/drivers/tc/tc_interrupt.h \
 ../src/ASF/sam0/drivers/tc/tc.h ../src/ASF/sam0/drivers/wdt/wdt.h \
 ../src/ASF/sam0/drivers/wdt/wdt_callback.h \
 ../src/ASF/sam0/drivers/wdt/wdt.h \
 ../src/ASF/sam0/drivers/wdt/wdt_callback.h ../src/sail_radio.h \
 ../src/sail_eeprom.h ../src/sail_types.h ../src/sail_wind.h \
 ../src/sail_debug.h ../src/sail_uart.h ../src/sail_tasksinit.h \
 ../src/sail_nmea.h ../src/Sail_WEATHERSTATION.h

../src/sail_ctrl.h:

../src/ASF/common2/services/delay/delay.h:

../src/ASF/common2/services/delay/sam0/cycle_counter.h:

../src/ASF/sam0/utils/compiler.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stddef.h:

../src/ASF/common/utils/parts.h:

../src/ASF/sam0/utils/status_codes.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdint.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\stdint.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_default_types.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\features.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_newlib_version.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_intsup.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_stdint.h:

../src/ASF/sam0/utils/preprocessor/preprocessor.h:

../src/ASF/sam0/utils/preprocessor/tpaste.h:

../src/ASF/sam0/utils/preprocessor/stringz.h:

../src/ASF/sam0/utils/preprocessor/mrepeat.h:

../src/ASF/sam0/utils/preprocessor/preprocessor.h:

../src/ASF/sam0/utils/preprocessor/mrecursion.h:

../src/ASF/sam0/utils/header_files/io.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdbool.h:

../src/ASF/sam0/utils/cmsis/samd20/include/samd20.h:

../src/ASF/sam0/utils/cmsis/samd20/include/samd20j18.h:

../src/ASF/thirdparty/CMSIS/Include/core_cm0plus.h:

../src/ASF/thirdparty/CMSIS/Include/cmsis_version.h:

../src/ASF/thirdparty/CMSIS/Include/cmsis_compiler.h:

../src/ASF/thirdparty/CMSIS/Include/cmsis_gcc.h:

../src/ASF/sam0/utils/cmsis/samd20/source/system_samd20.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/ac.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/adc.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/dac.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/dsu.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/eic.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/evsys.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/gclk.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/nvmctrl.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/pac.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/pm.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/port.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/rtc.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/sercom.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/sysctrl.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/tc.h:

../src/ASF/sam0/utils/cmsis/samd20/include/component/wdt.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/ac.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/adc.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/dac.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/dsu.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/eic.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/evsys.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/gclk.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/nvmctrl.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/pac0.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/pac1.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/pac2.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/pm.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/port.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/rtc.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom0.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom1.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom2.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom3.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom4.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/sercom5.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/sysctrl.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc0.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc1.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc2.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc3.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc4.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc5.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc6.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/tc7.h:

../src/ASF/sam0/utils/cmsis/samd20/include/instance/wdt.h:

../src/ASF/sam0/utils/cmsis/samd20/include/pio/samd20j18.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\stdio.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_ansi.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\newlib.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\config.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\ieeefp.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\cdefs.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdarg.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\reent.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_ansi.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_types.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_types.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\lock.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\types.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\endian.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_endian.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\select.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_sigset.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_timeval.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\timespec.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_timespec.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_pthreadtypes.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\types.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\stdio.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\stdlib.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\stdlib.h:

d:\microchip\ studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\alloca.h:

../src/ASF/common/utils/interrupt.h:

../src/ASF/common/utils/interrupt/interrupt_sam_nvic.h:

../src/ASF/sam0/drivers/system/clock/clock.h:

../src/ASF/sam0/drivers/system/clock/gclk.h:

../src/ASF/sam0/drivers/system/clock/clock_samd20/clock_feature.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/FreeRTOS.h:

../src/config/FreeRTOSConfig.h:

../src/ASF/common/boards/board.h:

../src/ASF/sam0/boards/samd20_xplained_pro/samd20_xplained_pro.h:

../src/config/conf_board.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/projdefs.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/portable.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/deprecated_definitions.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/portable/GCC/ARM_CM0/portmacro.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/mpu_wrappers.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/task.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/list.h:

../src/asf.h:

../src/ASF/sam0/drivers/adc/adc.h:

../src/ASF/sam0/drivers/system/system.h:

../src/ASF/sam0/drivers/system/pinmux/pinmux.h:

../src/ASF/sam0/drivers/system/power/power_sam_d_r_h/power.h:

../src/ASF/sam0/drivers/system/reset/reset_sam_d_r_h/reset.h:

../src/ASF/sam0/drivers/adc/adc_sam_d_r_h/adc_feature.h:

../src/ASF/sam0/drivers/system/interrupt/system_interrupt.h:

../src/ASF/sam0/drivers/system/interrupt/system_interrupt_samd20/system_interrupt_features.h:

../src/ASF/sam0/drivers/adc/adc_callback.h:

../src/ASF/common/services/freertos/dbg_print/dbg_print.h:

../src/config/conf_dbg_print.h:

../src/ASF/common/services/freertos/dbg_print/quick_start_basic/qs_dbg_print_basic.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/StackMacros.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/croutine.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/deprecated_definitions.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/event_groups.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/timers.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/task.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/list.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/message_buffer.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/stream_buffer.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/mpu_wrappers.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/portable.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/projdefs.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/queue.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/semphr.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/queue.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/stack_macros.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/stream_buffer.h:

../src/ASF/thirdparty/freertos/freertos-10.0.0/Source/include/timers.h:

../src/ASF/sam0/drivers/port/port.h:

../src/ASF/sam0/drivers/rtc/rtc_count.h:

../src/config/conf_clocks.h:

../src/ASF/sam0/drivers/rtc/rtc_count_interrupt.h:

../src/ASF/sam0/drivers/rtc/rtc_count.h:

../src/ASF/sam0/drivers/rtc/rtc_tamper.h:

../src/ASF/sam0/drivers/sercom/sercom.h:

../src/ASF/sam0/drivers/sercom/sercom_pinout.h:

../src/ASF/sam0/drivers/sercom/sercom_interrupt.h:

../src/ASF/sam0/drivers/sercom/sercom.h:

../src/ASF/sam0/drivers/sercom/i2c/i2c_common.h:

../src/ASF/sam0/drivers/sercom/i2c/i2c_master.h:

../src/ASF/sam0/drivers/sercom/i2c/i2c_common.h:

../src/ASF/sam0/drivers/sercom/i2c/i2c_master_interrupt.h:

../src/ASF/sam0/drivers/sercom/i2c/i2c_master.h:

../src/ASF/sam0/drivers/sercom/usart/usart.h:

../src/ASF/sam0/drivers/sercom/usart/usart_interrupt.h:

../src/ASF/sam0/drivers/sercom/usart/usart.h:

../src/ASF/sam0/drivers/tc/tc.h:

../src/ASF/sam0/drivers/tc/tc_interrupt.h:

../src/ASF/sam0/drivers/tc/tc.h:

../src/ASF/sam0/drivers/wdt/wdt.h:

../src/ASF/sam0/drivers/wdt/wdt_callback.h:

../src/ASF/sam0/drivers/wdt/wdt.h:

../src/ASF/sam0/drivers/wdt/wdt_callback.h:

../src/sail_radio.h:

../src/sail_eeprom.h:

../src/sail_types.h:

../src/sail_wind.h:

../src/sail_debug.h:

../src/sail_uart.h:

../src/sail_tasksinit.h:

../src/sail_nmea.h:

../src/Sail_WEATHERSTATION.h:
